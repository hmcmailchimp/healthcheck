﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HealthCheck.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "EmployeeService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select EmployeeService.svc or EmployeeService.svc.cs at the Solution Explorer and start debugging.
    public class EmployeeService : IEmployeeService
    {
        private static readonly Dictionary<int, Employee> _employees = new Dictionary<int, Employee>
    {
        { 1, new Employee { Id = 1, Name = "John Doe" } },
        { 2, new Employee { Id = 2, Name = "Jane Smith" } },
        { 3, new Employee { Id = 2, Name = "Raj Kumar" } },
        { 4, new Employee { Id = 2, Name = "Sathish Kumar" } },
        { 5, new Employee { Id = 2, Name = "Uma Maheswari" } }
    };

        public Employee GetEmployee(int id) => _employees.TryGetValue(id, out var emp) ? emp : null;

        public List<Employee> GetAllEmployees() => _employees.Values.ToList();
    }
}

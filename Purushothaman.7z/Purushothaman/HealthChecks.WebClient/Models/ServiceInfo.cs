using System.Collections.Generic;

namespace HealthChecks.WebClient.Models
{
    public class ServiceInfo
    {
        public string Name { get; set; }
        public List<MethodInfo> Methods { get; set; }
    }

    public class MethodInfo
    {
        public string ApiName { get; set; }
    }
}

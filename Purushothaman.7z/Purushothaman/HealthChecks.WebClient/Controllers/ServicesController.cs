using HealthChecks.WebClient.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace HealthChecks.WebClient.Controllers
{
    public class ServicesController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;
        public ServicesController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index()
        {
            var client = _httpClientFactory.CreateClient();
            var response = await client.GetAsync("http://localhost:5200/api/HealthCheck/all-services?includeMethods=true&loadEnvironment=dev");
            var json = await response.Content.ReadAsStringAsync();
            var services = JsonConvert.DeserializeObject<List<ServiceInfo>>(json);
            return View(services);
        }

        [HttpPost]
        public async Task<IActionResult> GetServiceDetails([FromBody] ServiceDetailsRequest request)
        {
            var client = _httpClientFactory.CreateClient();
            var url = $"http://localhost:5200/api/HealthCheck/services-details?includeMethods=true&loadEnvironment={request.Environment}";
            var body = JsonConvert.SerializeObject(request.SelectedServices);
            var httpContent = new StringContent(body, System.Text.Encoding.UTF8, "application/json");
            var response = await client.PostAsync(url, httpContent);
            var json = await response.Content.ReadAsStringAsync();
            var details = JsonConvert.DeserializeObject<List<HealthCheckResponse>>(json);
            return Json(details);
        }
    }

    public class ServiceDetailsRequest
    {
        public List<ServiceInfo> SelectedServices { get; set; }
        public string Environment { get; set; }
    }
    
}

# HealthCheck.API

This project is an ASP.NET Core WebAPI for performing health checks on WCF (.svc), Web Services (.asmx), and ASP.NET WebAPI endpoints. It supports environment-specific configuration using JSON files for dev, QA, UAT, and prod.

## Environments
- `appsettings.Development.json`
- `appsettings.QA.json`
- `appsettings.UAT.json`
- `appsettings.Production.json`

## Getting Started
1. Update the endpoint URLs in the appropriate appsettings JSON file under the `HealthCheckEndpoints` section.
2. Build and run the API:
   ```powershell
   dotnet build
   dotnet run --project HealthCheck.API
   ```
3. Access the health check endpoint (e.g., `/api/healthcheck`).

## Configuration Example
```
"HealthCheckEndpoints": {
  "WcfServices": ["http://example.com/service1.svc"],
  "AsmxServices": ["http://example.com/service2.asmx"],
  "WebApis": ["http://example.com/api/values"]
}
```

## Notes
- Ensure the correct environment is set using the `ASPNETCORE_ENVIRONMENT` variable.
- Add or update endpoints as needed for each environment.

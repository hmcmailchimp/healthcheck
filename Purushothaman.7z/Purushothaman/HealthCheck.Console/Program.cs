﻿

using System;
using System.Net.Http;
using System.Configuration;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;

// Change to your deployed API URL if needed
var config = new ConfigurationBuilder().SetBasePath(AppContext.BaseDirectory).AddJsonFile("appsettings.json", optional: false, reloadOnChange: true).Build();
string apiBaseUrl = config.GetSection("healthCheckScanUrl").Value;
using (HttpClient client = new HttpClient())
{
    client.BaseAddress = new Uri(apiBaseUrl);
    client.DefaultRequestHeaders.Accept.Clear();
    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

    if (args.Length > 1)
    {
        if (args[0].Equals("quickscan", StringComparison.OrdinalIgnoreCase))
        {
            var response = await client.GetAsync(string.Concat(apiBaseUrl, "/quick-scan?sendEmailNotification=true&loadEnvironment=", args[1]));
            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadAsStringAsync();
                Console.WriteLine("QuickScan Result: " + result);
            }
            else
            {
                Console.WriteLine($"QuickScan API call failed: {response.StatusCode}");
            }
        }
        else if (args[0].Equals("detailedscan", StringComparison.OrdinalIgnoreCase))
        {
            
            var response = await client.GetAsync(string.Concat(apiBaseUrl, "/detailed-scan?sendEmailNotification=true&loadEnvironment=", args[1]));
            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadAsStringAsync();
                Console.WriteLine("DetailedScan Result: " + result);
            }
            else
            {
                Console.WriteLine($"DetailedScan API call failed: {response.StatusCode}");
            }
        }
        else
        {
            Console.WriteLine("Unknown argument. Use 'quickscan & environment' or 'detailedscan & environment'.");
        }
    }
    else
    {
        Console.WriteLine("Please provide an argument: 'quickscan & environment' or 'detailedscan & environment'.");
    }
}

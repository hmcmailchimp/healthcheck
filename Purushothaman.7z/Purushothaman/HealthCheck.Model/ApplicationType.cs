﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Model
{
    public enum ApplicationType
    {
        GenericUrls = 1,
        WebAPI = 2,
        Webservices = 3,
        WCF = 4
    }
}

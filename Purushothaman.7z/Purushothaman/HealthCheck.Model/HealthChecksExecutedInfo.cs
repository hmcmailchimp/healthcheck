﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Model
{
    public class HealthChecksExecutedInfo
    {
        public DateTime StartDateTime {  get; set; }
        public DateTime EndDateTime { get; set; }
        public string Duration { get; set; }
    }
}

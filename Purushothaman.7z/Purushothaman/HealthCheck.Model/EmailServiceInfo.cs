﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Model
{
    public class EmailServiceInfo
    {
        public ServiceInfo ServiceInfo { get; set; }
        public MethodInfo MethodInfo { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
        public string Duration { get; set; }
        public HttpStatusCode HttpReturnCode { get; set; }
        public int OrderStatusCode { get; set; }
        public string Status { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Model
{
    public class ServiceInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string url { get; set; }
        public bool IsExcludeInQuickScan { get; set; }
        public bool IsExcludedInDetailedScan { get; set; }
        public bool IsCustmizableHealthCheck { get; set; }
        public string CustmizableHealthCheckName { get; set; }
        public int AppplicationType { get; set; }
        public List<MethodInfo> Methods { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Model
{
    public class EmailData
    {
        public  string EmailAddress { get; set; }
        public string DisplayName { get; set; }
    }
}

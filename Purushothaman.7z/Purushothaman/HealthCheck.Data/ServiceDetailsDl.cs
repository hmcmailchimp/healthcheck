﻿using HealthCheck.Data.Interface;
using HealthCheck.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Data
{
    public class ServiceDetailsDl:IServiceDetailsDl
    {
        public List<ServiceInfo> GetAllServices(bool includeMethods, string LoadEnvironment)
        {
            List<ServiceInfo> services = GetAllServicesDetails(LoadEnvironment);
            if (!includeMethods)
            {
                foreach (ServiceInfo serviceInfo in services)
                {
                    serviceInfo.Methods = [];
                }
            }
            return services.Where(x => x.url != string.Empty).OrderBy(x => x.Name).ToList();
        }
        private List<ServiceInfo> GetAllServicesDetails(string LoadEnvironment)
        {
            var services = new List<ServiceInfo>();
            string json = File.ReadAllText(string.Concat(@"JsonData\", LoadEnvironment, "_ServiceConfig.json"));
            services = JsonConvert.DeserializeObject<List<ServiceInfo>>(json);
            return services.Where(x => x.url != string.Empty).OrderBy(x => x.Name).ToList();
        }
    }
}

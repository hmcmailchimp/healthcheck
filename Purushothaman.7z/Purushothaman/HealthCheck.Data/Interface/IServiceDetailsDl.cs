﻿using HealthCheck.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Data.Interface
{
    public interface IServiceDetailsDl
    {
        public List<ServiceInfo> GetAllServices(bool includeMethods, string LoadEnvironment);
    }
}

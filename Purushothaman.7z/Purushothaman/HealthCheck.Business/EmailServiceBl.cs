﻿using HealthCheck.Business.Interface;
using HealthCheck.Model;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Xsl;

namespace HealthCheck.Business
{
    public class EmailServiceBl : IEmailServiceBl
    {
        static IConfiguration _configuration;

        public EmailServiceBl(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public bool SendEmail(bool IncludeMethods, List<HealthCheckResponse> response, HealthChecksExecutedInfo executeInfo, string LoadEnvironment)
        {
            string LoadTestEnvironment = LoadEnvironment;
            EmailTemplateInfo templateInfo = new EmailTemplateInfo();
            templateInfo.EmailBodyText = _configuration.GetSection("BodyEmailContent").Value.Replace("${LoadTestEnvironment}", LoadEnvironment);
            templateInfo.HealthChecksExecutedInfo = executeInfo;
            templateInfo.serviceInfo = GetListMappedClassResult(response);

            // Send email using free SMTP (e.g., SMTP)
            
            string subject = string.Concat(_configuration.GetSection("subjectQuickScanEmail").Value, LoadEnvironment);
            string smptServer = _configuration.GetSection("SmtpServer").Value;
            string smptPort = _configuration.GetSection("SmtpPort").Value;
            string smptServerUser = _configuration.GetSection("SmtpServerUser").Value;
            string smptServerPassword = _configuration.GetSection("SmtpServerPw").Value;

            if (IncludeMethods) 
            {
                subject = string.Concat(_configuration.GetSection("subjectDetailedScanEmail").Value, LoadEnvironment);
            }

            try
            {
                string fromEmail = _configuration.GetSection("FromEmail").Value;                
                //var smtpClient = new System.Net.Mail.SmtpClient(smptServer)
                //{
                //    Port = Convert.ToInt32(smptPort),
                //    Credentials = new System.Net.NetworkCredential(smptServerUser, smptServerPassword),
                //    EnableSsl = true,
                //};
                var mailMessage = new System.Net.Mail.MailMessage
                {
                    From = new System.Net.Mail.MailAddress(fromEmail),
                    Subject = "HealthCheck Report - " + LoadTestEnvironment,
                    Body = GetEmailHTMLBodyContent(IncludeMethods, templateInfo),
                    IsBodyHtml = true,
                };
                
                string toEmail = _configuration.GetSection("ToEmail").Value;
                foreach (var toemail in toEmail.Split(';'))
                {
                    if (!string.IsNullOrEmpty(toemail))
                    {
                        mailMessage.To.Add(toemail); // Set recipient
                    }
                }

                string ccEmail = _configuration.GetSection("ccEmail").Value;
                foreach (var ccemail in ccEmail.Split(';'))
                {
                    if (!string.IsNullOrEmpty(ccemail))
                    {
                        mailMessage.CC.Add(ccemail);
                    }
                }

                string BccEmail = _configuration.GetSection("BccEmail").Value;
                foreach (var bccEmail in BccEmail.Split(';'))
                {
                    if (!string.IsNullOrEmpty(bccEmail))
                    {
                        mailMessage.Bcc.Add(bccEmail);
                    }
                }
                var smtpClient = new System.Net.Mail.SmtpClient(smptServer, Convert.ToInt32(smptPort));
                smtpClient.EnableSsl = true;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new NetworkCredential(smptServerUser, smptServerPassword);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex)
            {
                // Log or handle error
                return false;
            }
            return true;
        }

        private string GetEmailHTMLBodyContent(bool includeMethods, EmailTemplateInfo templateInfo)
        {
            XslCompiledTransform xslCompiledTransform = new XslCompiledTransform();
            System.Xml.Serialization.XmlSerializer xmlSerializer = new System.Xml.Serialization.XmlSerializer(templateInfo.GetType());
            string uniqueId = Guid.NewGuid().ToString("N");
            StreamWriter xmlWriter = null;
            string ScanInputXmlPath = string.Empty;
            if (includeMethods)
            {
                xslCompiledTransform.Load(@"EmailTemplate\DetailedScan.xsl");
                ScanInputXmlPath = @"EmailTemplate\" + uniqueId + "_DetailedScan.xml";
                if (File.Exists(ScanInputXmlPath))
                {
                    File.Delete(ScanInputXmlPath);
                }
                xmlWriter = new StreamWriter(ScanInputXmlPath);
            }
            else
            {
                xslCompiledTransform.Load(@"EmailTemplate\QuickScan.xsl");
                ScanInputXmlPath = @"EmailTemplate\" + uniqueId + "_QuickScan.xml";
                if (File.Exists(ScanInputXmlPath))
                {
                    File.Delete(ScanInputXmlPath);
                }
                xmlWriter = new StreamWriter(ScanInputXmlPath);
            }

            xmlSerializer.Serialize(xmlWriter, templateInfo);
            xmlWriter.Close();

            //Transform the files and output an Html string
            StringWriter stringWriter = new StringWriter();
            xslCompiledTransform.Transform(ScanInputXmlPath, null, stringWriter);
            string htmlOutput = stringWriter.ToString();
            stringWriter.Close();

            //Delete after html value bind
            if (File.Exists(ScanInputXmlPath))
            {
                File.Delete(ScanInputXmlPath);
            }

            return htmlOutput;
        }

        private List<EmailServiceInfo> GetListMappedClassResult(List<HealthCheckResponse> healthCheckResponses)
        {
            List<EmailServiceInfo> healthCheckEmailInfo = (from HealthCheckResponse response in healthCheckResponses
                                                           select new EmailServiceInfo()
                                                           {
                                                               ServiceInfo = response.ServiceInfo,
                                                               MethodInfo = response.MethodInfo,
                                                               StartDateTime = response.StartDateTime,
                                                               EndDateTime = response.EndDateTime,
                                                               Duration = response.Duration.ToString(),
                                                               OrderStatusCode = response.OrderStatusCode,
                                                               Status = (response.HttpReturnCode == System.Net.HttpStatusCode.OK ? "Success" : "Fail"),
                                                               HttpReturnCode = response.HttpReturnCode
                                                           }).ToList().OrderByDescending(x=> x.OrderStatusCode).ToList();
            return healthCheckEmailInfo;
        }
    }
}

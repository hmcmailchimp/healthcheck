﻿using HealthCheck.Business.HealthCheckImplementation;
using HealthCheck.Business.Interface;
using HealthCheck.Data.Interface;
using HealthCheck.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace HealthCheck.Business
{
    public class ServicesDetailsBl: IServiceDetailsBl
    {
        IServiceDetailsDl _serviceDetailsDl;
        public ServicesDetailsBl(IServiceDetailsDl serviceDetailsDl) {
            _serviceDetailsDl = serviceDetailsDl;
        }
        public List<ServiceInfo> GetAllServices(bool includeMethods, string LoadEnvironment)
        {
           List<ServiceInfo> services =  _serviceDetailsDl.GetAllServices(includeMethods, LoadEnvironment);
            if (includeMethods)
            {
                return services.Where(x => x.IsExcludedInDetailedScan == false).ToList();
            }
            else
            {
                return services.Where(x => x.IsExcludeInQuickScan == false).ToList();
            }
        }        

        public async Task<List<HealthCheckResponse>> GetServicesDetails(bool includeMethods, List<ParentChild> inputSelector, string LoadEnvironment)
        {
            List<HealthCheckResponse> healthCheckResponseLst = new List<HealthCheckResponse>();
            List<ServiceInfo> selectedServices = new List<ServiceInfo>();
            List<ServiceInfo> allServices = _serviceDetailsDl.GetAllServices(includeMethods, LoadEnvironment);
            foreach (ParentChild serviceInfo in inputSelector)
            {
                ServiceInfo service = allServices.FirstOrDefault(x => x.Name.ToUpper() == serviceInfo.Parent.ToUpper());
                if (service != null)
                {
                    service.Methods = (from allMethods in service.Methods.ToList()
                                       join selectedMethods in serviceInfo.Children.ToList() on allMethods.ApiName.
                                      ToUpper() equals selectedMethods.ToUpper()
                                       select allMethods).ToList();
                    selectedServices.Add(service);
                }
            }
            if (includeMethods)
            {
                foreach (ServiceInfo serviceInfo in selectedServices)
                {
                    foreach(MethodInfo methodInfo in serviceInfo.Methods)
                    {
                        var healthCheckResponse = PerformDetailedScan(serviceInfo, methodInfo);
                        healthCheckResponseLst.Add(healthCheckResponse.Result);
                    }                    
                }
            }
            else
            {
                foreach (ServiceInfo serviceInfo in selectedServices)
                {
                    var healthCheckResponse = PerformQuickScan(serviceInfo);
                    healthCheckResponseLst.Add(healthCheckResponse);
                }
            }
            return healthCheckResponseLst.OrderByDescending(x=> x.OrderStatusCode).ToList();
        }

        public HealthCheckResponse PerformQuickScan(ServiceInfo serviceInfo)
        {
            return HttpGetUrlHealthChecks.PerformHttpGetUrlHealthCheck(serviceInfo);
        }

        public async Task<HealthCheckResponse> PerformDetailedScan(ServiceInfo serviceInfo, MethodInfo methodInfo)
        {
            if (serviceInfo.AppplicationType == (int)ApplicationType.WebAPI)
            {
                return await WebAPIHealthCheck.PerformWebAPIHealthCheck(serviceInfo, methodInfo);
            }
            else if (serviceInfo.AppplicationType == (int)ApplicationType.WCF)
            {
                return await WCFHealthCheck.PerformWCFHealthCheck(serviceInfo, methodInfo);
            }
            else
            {
                return await WebServicesHealthCheck.PerformWebServicesHealthCheck(serviceInfo, methodInfo);
            }
        }
    }
}

﻿using HealthCheck.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Business.Interface
{
    public interface IServiceDetailsBl
    {
        public HealthCheckResponse PerformQuickScan(ServiceInfo serviceInfo);
        public Task<HealthCheckResponse> PerformDetailedScan(ServiceInfo serviceInfo, MethodInfo methodInfo);
        public List<ServiceInfo> GetAllServices(bool includeMethods, string LoadEnvironment);
        public Task<List<HealthCheckResponse>> GetServicesDetails(bool includeMethods, List<ParentChild> inputSelector, string LoadEnvironment);
    }
}

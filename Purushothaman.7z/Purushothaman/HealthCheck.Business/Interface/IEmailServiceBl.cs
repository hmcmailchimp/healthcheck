﻿using HealthCheck.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Business.Interface
{
    public interface IEmailServiceBl
    {
        public bool SendEmail(bool IncludeMethods, List<HealthCheckResponse> response, HealthChecksExecutedInfo executeInfo, string LoadEnvironment);
    }
}

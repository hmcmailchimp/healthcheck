﻿using HealthCheck.Model;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices.Marshalling;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Business.HealthCheckImplementation
{
    public class WebAPIHealthCheck
    {
        static IConfiguration _configuration;

        public WebAPIHealthCheck(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public static async Task<HealthCheckResponse> PerformWebAPIHealthCheck(ServiceInfo serviceInfo, MethodInfo methodInfo)
        {
            string webUrl = string.Concat(serviceInfo.url, methodInfo.SoapServiceAction);
            HealthCheckResponse healthCheckResponse = new HealthCheckResponse();

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromMinutes(60);
                    client.BaseAddress = new Uri(webUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                    HttpRequestMessage request = new HttpRequestMessage();

                    if (methodInfo.HttpMethod.ToUpper().Equals("GET"))
                    {
                        request = new HttpRequestMessage(HttpMethod.Get, webUrl);
                    }
                    else if (methodInfo.HttpMethod.ToUpper().Equals("POST"))
                    {
                        request = new HttpRequestMessage(HttpMethod.Post, webUrl);
                    }
                    else if (methodInfo.HttpMethod.ToUpper().Equals("PUT"))
                    {
                        request = new HttpRequestMessage(HttpMethod.Put, webUrl);
                    }
                    else if (methodInfo.HttpMethod.ToUpper().Equals("PATCH"))
                    {
                        request = new HttpRequestMessage(HttpMethod.Patch, webUrl);
                    }
                    else if (methodInfo.HttpMethod.ToUpper().Equals("DELETE"))
                    {
                        request = new HttpRequestMessage(HttpMethod.Delete, webUrl);
                    }

                    client.DefaultRequestHeaders.Accept.Clear(); 
                    healthCheckResponse.StartDateTime = DateTime.Now;
                    healthCheckResponse.ServiceInfo = serviceInfo;
                    healthCheckResponse.MethodInfo = methodInfo;

                    if (!string.IsNullOrEmpty(methodInfo.RequestBasePath))
                    {
                        //request.Headers.Add("Content-Type", "text/xml; charset=utf-8")
                        string contentPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, methodInfo.RequestBasePath);
                        string jsonstring = await File.ReadAllTextAsync(contentPath);
                        request.Content = new StringContent(jsonstring, Encoding.UTF8, "applicaion/json");                                         
                    }

                    using (var response = (HttpResponseMessage)client.SendAsync(request).Result)
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            healthCheckResponse.OrderStatusCode = 0;
                            healthCheckResponse.HttpReturnCode = response.StatusCode;
                            var result = await response.Content.ReadAsStringAsync();
                        }
                        else
                        {
                            healthCheckResponse.OrderStatusCode = 3;
                            healthCheckResponse.HttpReturnCode = response.StatusCode;
                            WebException exception = new WebException(response.ReasonPhrase.ToString(), (WebExceptionStatus)healthCheckResponse.HttpReturnCode);
                            WriteErrorLog.WriteWebExceptionErrorLog(exception, serviceInfo, methodInfo.ApiName, healthCheckResponse.HttpReturnCode);
                        }
                    }
                }
            }            
            catch (Exception ex)
            {
                healthCheckResponse.OrderStatusCode = 3;
                healthCheckResponse.HttpReturnCode = HttpStatusCode.BadRequest;
                healthCheckResponse.Message = ex.Message;
                WriteErrorLog.WriteExceptionErrorLog(ex, serviceInfo, string.Empty, healthCheckResponse.HttpReturnCode);
            }

            healthCheckResponse.EndDateTime = DateTime.Now;
            healthCheckResponse.Duration = (healthCheckResponse.EndDateTime - healthCheckResponse.StartDateTime).ToString(@"hh\:mm\:ss");
            return healthCheckResponse;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Model
{
    public class EmailTemplateInfo
    {
        public string EmailBodyText {  get; set; }
        public HealthChecksExecutedInfo HealthChecksExecutedInfo { get; set; }
        public List<EmailServiceInfo> serviceInfo { get; set; }

    }
}

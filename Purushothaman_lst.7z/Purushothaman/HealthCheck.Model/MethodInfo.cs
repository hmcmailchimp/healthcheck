﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Model
{
    public class MethodInfo
    {
        public int ServiceId { get; set; }
        public string ApiName { get; set; }
        public string HttpMethod { get; set; }
        public string SoapServiceAction { get; set; }
        public string RequestBasePath { get; set; }
    }

    public class ParentChildRequest
    {
        public string loadEnvironment { get; set; }
        public bool includeMethods { get; set; }
        public List<ParentChild> selections { get; set; }
    }

    public class ParentChild
    {
        public string Parent { get; set; }
        public List<string> Children { get; set; }
    }
}

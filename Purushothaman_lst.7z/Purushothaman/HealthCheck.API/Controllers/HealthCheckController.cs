using HealthCheck.Business.Interface;
using HealthCheck.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace HealthCheck.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HealthCheckController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IServiceDetailsBl _serviceDetailsBl;
        private readonly IEmailServiceBl _emailServiceBl;

        public HealthCheckController(IConfiguration configuration, IServiceDetailsBl serviceDetailsBl, IEmailServiceBl emailServiceBl)
        {
            _configuration = configuration;
            _serviceDetailsBl = serviceDetailsBl;
            _emailServiceBl = emailServiceBl;
        }        

        [HttpPost("parent-child-list")]
        public Task<List<HealthCheckResponse>> GetParentChildList([FromBody] ParentChildRequest request)
        {
            var result = new List<ParentChild>();
            foreach (var sel in request.selections)
            {
                result.Add(new ParentChild
                {
                    Parent = sel.Parent,
                    Children = sel.Children ?? new List<string>()
                }); }

               return  _serviceDetailsBl.GetServicesDetails(request.includeMethods, result, request.loadEnvironment);
        }

        [HttpGet("all-services")]
        public ActionResult<List<ServiceInfo>> GetAllServices([FromQuery] bool includeMethods, [FromQuery] string loadEnvironment)
        {
            var result = _serviceDetailsBl.GetAllServices(includeMethods, loadEnvironment);
            return Ok(result);
        }

        [HttpGet("quick-scan")]
        public ActionResult<List<HealthCheckResponse>> PerformQuickScan([FromQuery] bool sendEmailNotification, [FromQuery] string loadEnvironment)
        {
            List<HealthCheckResponse> healthCheckResponselst = new List<HealthCheckResponse>();
            HealthChecksExecutedInfo healthChecksExecutedInfo = new HealthChecksExecutedInfo();
            List<ServiceInfo> services = _serviceDetailsBl.GetAllServices(false, loadEnvironment);
            healthChecksExecutedInfo.StartDateTime = DateTime.Now;

            foreach (ServiceInfo serviceInfo in services) {
                HealthCheckResponse healthCheckResponse = _serviceDetailsBl.PerformQuickScan(serviceInfo);
                healthCheckResponselst.Add(healthCheckResponse);
            }

            if (sendEmailNotification)
            {
                healthChecksExecutedInfo.EndDateTime = DateTime.Now;
                healthChecksExecutedInfo.Duration = (healthChecksExecutedInfo.EndDateTime - healthChecksExecutedInfo.StartDateTime).ToString(@"hh\:mm\:ss");
                _emailServiceBl.SendEmail(false, healthCheckResponselst, healthChecksExecutedInfo, loadEnvironment);
            }

            return Ok(healthCheckResponselst);
        }  

        [HttpGet("detailed-scan")]
        public async Task<ActionResult<List<HealthCheckResponse>>> PerformDetailedScan([FromQuery] bool sendEmailNotification, [FromQuery] string loadEnvironment)
        {
            List<HealthCheckResponse> healthCheckResponselst = new List<HealthCheckResponse>();
            HealthChecksExecutedInfo healthChecksExecutedInfo = new HealthChecksExecutedInfo();
            List<ServiceInfo> services = _serviceDetailsBl.GetAllServices(true, loadEnvironment);
            healthChecksExecutedInfo.StartDateTime = DateTime.Now;

            foreach (ServiceInfo serviceInfo in services)
            {
                foreach (MethodInfo methodInfo in serviceInfo.Methods)
                {
                    HealthCheckResponse healthCheckResponse = await _serviceDetailsBl.PerformDetailedScan(serviceInfo, methodInfo);
                    healthCheckResponselst.Add(healthCheckResponse);
                }
            }

            if (sendEmailNotification)
            {
                healthChecksExecutedInfo.EndDateTime = DateTime.Now;
                healthChecksExecutedInfo.Duration = (healthChecksExecutedInfo.EndDateTime - healthChecksExecutedInfo.StartDateTime).ToString(@"hh\:mm\:ss");
                _emailServiceBl.SendEmail(true, healthCheckResponselst, healthChecksExecutedInfo, loadEnvironment);
            }

            return Ok(healthCheckResponselst);
        }

    }
}

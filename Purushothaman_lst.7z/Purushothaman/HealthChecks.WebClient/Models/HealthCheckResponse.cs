using System.Collections.Generic;

namespace HealthChecks.WebClient.Models
{
    public class HealthCheckResponse
    {
        public string ServiceName { get; set; }
        public string ApiName { get; set; }
        public string Status { get; set; }
        public string Environment { get; set; }
        // Add other properties as needed
    }
}

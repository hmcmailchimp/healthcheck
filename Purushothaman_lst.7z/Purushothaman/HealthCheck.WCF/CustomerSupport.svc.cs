﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HealthCheck.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "EmployeeService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select EmployeeService.svc or EmployeeService.svc.cs at the Solution Explorer and start debugging.
    public class CustomerSupport : ICustomerSupport
    {
        private static readonly Dictionary<int, Customer> _customers = new Dictionary<int, Customer>
    {
        { 1, new Customer { Id = 1, Name = "John Doe" } },
        { 2, new Customer { Id = 2, Name = "Jane Smith" } },
        { 3, new Customer { Id = 2, Name = "Raj Kumar" } },
        { 4, new Customer { Id = 2, Name = "Sathish Kumar" } },
        { 5, new Customer { Id = 2, Name = "Uma Maheswari" } }
    };

        public Customer GetCustomer(int id) => _customers.TryGetValue(id, out var emp) ? emp : null;

        public List<Customer> GetAllCustomer() => _customers.Values.ToList();
    }
}

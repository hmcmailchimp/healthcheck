﻿using HealthCheck.Model;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Business.HealthCheckImplementation
{
    public class WebServicesHealthCheck
    {
        static IConfiguration _configuration;

        public WebServicesHealthCheck(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public static async Task<HealthCheckResponse> PerformWebServicesHealthCheck(ServiceInfo serviceInfo, MethodInfo methodInfo)
        {
            string webUrl = serviceInfo.url;
            HealthCheckResponse healthCheckResponse = new HealthCheckResponse();

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromMinutes(60);
                    client.BaseAddress = new Uri(webUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, methodInfo.SoapServiceAction);

                    client.DefaultRequestHeaders.Accept.Clear();
                    //request.Headers.Add("Content-Type", "text/xml; charset=utf-8");
                    request.Headers.Add("SoapAction", methodInfo.SoapServiceAction);

                    string contentPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, methodInfo.RequestBasePath);
                    string jsonstring = await File.ReadAllTextAsync(contentPath);

                    request.Content = new StringContent(jsonstring, Encoding.UTF8, "text/xml");

                    healthCheckResponse.StartDateTime = DateTime.Now;
                    healthCheckResponse.ServiceInfo = serviceInfo;
                    healthCheckResponse.MethodInfo = methodInfo;
                    using (var response = (HttpResponseMessage)client.SendAsync(request).Result)
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            healthCheckResponse.OrderStatusCode = 0;
                            healthCheckResponse.HttpReturnCode = response.StatusCode;
                            var result = await response.Content.ReadAsStringAsync();
                        }
                        else
                        {
                            healthCheckResponse.OrderStatusCode = 3;
                            healthCheckResponse.HttpReturnCode = response.StatusCode;
                            WebException exception = new WebException(response.ReasonPhrase.ToString(), (WebExceptionStatus)healthCheckResponse.HttpReturnCode);
                            WriteErrorLog.WriteWebExceptionErrorLog(exception, serviceInfo, methodInfo.ApiName, healthCheckResponse.HttpReturnCode);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                healthCheckResponse.OrderStatusCode = 3;
                healthCheckResponse.HttpReturnCode = HttpStatusCode.BadRequest;
                healthCheckResponse.Message = ex.Message;
                WriteErrorLog.WriteExceptionErrorLog(ex, serviceInfo, string.Empty, healthCheckResponse.HttpReturnCode);
            }

            healthCheckResponse.EndDateTime = DateTime.Now;
            healthCheckResponse.Duration = (healthCheckResponse.EndDateTime - healthCheckResponse.StartDateTime).ToString(@"hh\:mm\:ss");
            return healthCheckResponse;
        }
    }
}

﻿using HealthCheck.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Business.HealthCheckImplementation
{
    public class WriteErrorLog
    {
        public static void WriteWebExceptionErrorLog(WebException exception, ServiceInfo serviceInfo, string Message, HttpStatusCode httpStatusCode)
        {
            string logDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
            string logFilePath = Path.Combine(logDirectory, string.Concat("ErrorLog", DateTime.Now.ToString("DDMMYYYY"), ".txt"));

            try
            {
                // Ensure the directory exists
                if (!Directory.Exists(logDirectory))
                {
                    Directory.CreateDirectory(logDirectory);
                }

                // Write the error details to the log file
                using (StreamWriter writer = new StreamWriter(logFilePath, true))
                {
                    writer.WriteLine("Date: " + DateTime.Now);
                    writer.WriteLine("ServiceName: " + serviceInfo.Name);
                    if (string.IsNullOrEmpty(Message))
                    {
                        writer.WriteLine("ApiName: " + Message);
                    }
                    writer.WriteLine("Message: " + exception.Message);
                    writer.WriteLine("StackTrace: " + exception.StackTrace);
                    writer.WriteLine("--------------------------------------------------");
                }
            }
            catch (Exception logEx)
            {
                Console.WriteLine("Failed to write to log file: " + logEx.Message);
            }
        }

        public static void WriteUriFormatExceptionErrorLog(UriFormatException exception, ServiceInfo serviceInfo, string Message, HttpStatusCode httpStatusCode)
        {
            string logDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
            string logFilePath = Path.Combine(logDirectory, string.Concat("ErrorLog", DateTime.Now.ToString("DDMMYYYY"), ".txt"));

            try
            {
                // Ensure the directory exists
                if (!Directory.Exists(logDirectory))
                {
                    Directory.CreateDirectory(logDirectory);
                }

                // Write the error details to the log file
                using (StreamWriter writer = new StreamWriter(logFilePath, true))
                {
                    writer.WriteLine("Date: " + DateTime.Now);
                    writer.WriteLine("ServiceName: " + serviceInfo.Name);
                    writer.WriteLine("Message: " + exception.Message);
                    writer.WriteLine("StackTrace: " + exception.StackTrace);
                    writer.WriteLine("--------------------------------------------------");
                }
            }
            catch (Exception logEx)
            {
                Console.WriteLine("Failed to write to log file: " + logEx.Message);
            }
        }

        public static void WriteExceptionErrorLog(Exception exception, ServiceInfo serviceInfo, string Message, HttpStatusCode httpStatusCode)
        {
            string logDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
            string logFilePath = Path.Combine(logDirectory, string.Concat("ErrorLog", DateTime.Now.ToString("DDMMYYYY"), ".txt"));

            try
            {
                // Ensure the directory exists
                if (!Directory.Exists(logDirectory))
                {
                    Directory.CreateDirectory(logDirectory);
                }

                // Write the error details to the log file
                using (StreamWriter writer = new StreamWriter(logFilePath, true))
                {
                    writer.WriteLine("Date: " + DateTime.Now);
                    writer.WriteLine("ServiceName: " + serviceInfo.Name);
                    writer.WriteLine("Message: " + exception.Message);
                    writer.WriteLine("StackTrace: " + exception.StackTrace);
                    writer.WriteLine("--------------------------------------------------");
                }
            }
            catch (Exception logEx)
            {
                Console.WriteLine("Failed to write to log file: " + logEx.Message);
            }
        }

    }
}

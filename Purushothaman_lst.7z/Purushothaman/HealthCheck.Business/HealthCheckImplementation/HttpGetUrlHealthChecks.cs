﻿using HealthCheck.Model;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace HealthCheck.Business.HealthCheckImplementation
{
    public class HttpGetUrlHealthChecks
    {
        static IConfiguration _configuration;
        public HttpGetUrlHealthChecks(IConfiguration configuration) {
            _configuration = configuration;
        }
        public static HealthCheckResponse PerformHttpGetUrlHealthCheck(ServiceInfo serviceInfo)
        {
            string webUrl = serviceInfo.url;
            HealthCheckResponse healthCheckResponse = new HealthCheckResponse();
            if (serviceInfo.IsCustmizableHealthCheck)
            {
                webUrl = string.Concat(serviceInfo.url, "/", serviceInfo.CustmizableHealthCheckName);
            }
            try
            {
                healthCheckResponse.StartDateTime = DateTime.Now;
                HttpWebRequest webRequest = (HttpWebRequest)HttpWebRequest.Create(webUrl);
                webRequest.Timeout = System.Threading.Timeout.Infinite;
                webRequest.AllowWriteStreamBuffering = false;

                using (HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse())
                {
                    if (response != null) 
                    {
                        healthCheckResponse.HttpReturnCode = response.StatusCode;
                        healthCheckResponse.OrderStatusCode = 0;
                        healthCheckResponse.ServiceInfo = serviceInfo;
                        if(serviceInfo.IsCustmizableHealthCheck && serviceInfo.AppplicationType == (int)ApplicationType.WebAPI)
                        {
                            using(StreamReader reader = new StreamReader(response.GetResponseStream()))
                            {
                                var result = JsonConvert.DeserializeObject<HealthCheckStatus>(reader.ReadToEnd());
                                if(!result.StatusCode.Equals(_configuration.GetSection("HealthCheckStatus").Value))
                                {
                                    healthCheckResponse.OrderStatusCode = 3;
                                    healthCheckResponse.HttpReturnCode = HttpStatusCode.BadRequest;
                                    healthCheckResponse.Message = _configuration.GetSection("HealthCheckErrorMessage").Value;
                                    WebException exception = new WebException(healthCheckResponse.Message, (WebExceptionStatus)healthCheckResponse.HttpReturnCode);
                                    WriteErrorLog.WriteWebExceptionErrorLog(exception, serviceInfo, string.Empty, healthCheckResponse.HttpReturnCode);
                                }
                            }
                        }
                    }
                }
            }
            catch(UriFormatException ue)
            {
                healthCheckResponse.HttpReturnCode = HttpStatusCode.BadRequest;
                healthCheckResponse.Message = ue.Message;
                healthCheckResponse.OrderStatusCode = 3;
                WriteErrorLog.WriteUriFormatExceptionErrorLog(ue, serviceInfo, string.Empty, healthCheckResponse.HttpReturnCode);

            }
            catch(WebException wx)
            {
                healthCheckResponse.OrderStatusCode = 3;
                healthCheckResponse.HttpReturnCode = HttpStatusCode.BadRequest;
                healthCheckResponse.Message = wx.Message;
                WriteErrorLog.WriteWebExceptionErrorLog(wx, serviceInfo, string.Empty, healthCheckResponse.HttpReturnCode);
            }
            catch (Exception ex)
            {
                healthCheckResponse.OrderStatusCode = 3;
                healthCheckResponse.HttpReturnCode = HttpStatusCode.BadRequest;
                healthCheckResponse.Message = ex.Message;
                WriteErrorLog.WriteExceptionErrorLog(ex, serviceInfo, string.Empty, healthCheckResponse.HttpReturnCode);
            }
            
            healthCheckResponse.EndDateTime = DateTime.Now;
            healthCheckResponse.Duration = (healthCheckResponse.EndDateTime - healthCheckResponse.StartDateTime).ToString(@"hh\:mm\:ss");
            return healthCheckResponse;
        }
    }
}
